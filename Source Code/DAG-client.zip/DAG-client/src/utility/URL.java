package utility;

public class URL {
	
	public String getUrlPrefix() {
		return "https://localhost:8444/DAG-Server/";
	}

}
