package servlets;

public class productBean {

	public long id=0;
	public String name="";
	public String des="";
	public long startBid=0;
	public long endDate=0;
	public long result=0;
	
}
