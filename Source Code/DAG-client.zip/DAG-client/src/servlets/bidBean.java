package servlets;

public class bidBean {

	public long id=0;
	public String pname="";
	public long startBid=0;
	public long yourBid=0;
	public long endDate=0;
	public long result=0;
}
