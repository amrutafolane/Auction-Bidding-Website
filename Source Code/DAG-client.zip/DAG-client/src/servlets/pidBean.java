package servlets;

public class pidBean {
	public String Bidder="";
	public long amt=0;

}
